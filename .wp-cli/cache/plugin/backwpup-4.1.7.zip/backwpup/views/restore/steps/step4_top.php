<div class="metabox-holder postbox backwpup-cleared-postbox backwpup-full-width">
	<h3 class="hndle"><span><?php esc_html_e( 'Website Migration', 'backwpup' ); ?></span></h3>
	<div class="inside">
		<p><?php esc_html_e( 'If you would like to migrate your website to a new URL, enable the Migrate URL option below and enter the new URL.', 'backwpup' ); ?></p>
	</div>
</div>
