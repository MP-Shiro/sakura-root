<?php /** @var \stdClass $bind */ ?>
<?php

/**
 * Download Log.
 */

?>

<a class="button" href="<?php echo esc_url( $bind->link ); ?>">
	<?php echo esc_html( $bind->label ); ?>
</a>
